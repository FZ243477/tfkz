<?php


namespace app\seller\model;


use think\Model;

class Message extends Model
{

}