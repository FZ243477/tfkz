<?php


namespace app\buy\model;


use think\Model;

class Message extends Model
{

}